//
//  KJImageBrowserView.h
//  ImageBrowser
//
//  Created by chester on 7/9/14.
//  Copyright (c) 2014 MLL. All rights reserved.
//

#import <UIKit/UIKit.h>

/*
 use sample:
 
 
 NSArray *imageURLArray1 = [NSArray arrayWithObjects:imageURL1, imageURL2, imageURL3, imageURL4, nil];
 NSArray *imageURLArray2 = [NSArray arrayWithObjects:imageURL10, imageURL20, imageURL30, imageURL40, nil];
 
 
 KJImageBrowserView *imageBrower = [[KJImageBrowserView alloc]
                    initWithFrame:CGRectMake(50, 60, 800, 700)
                    padding:[NSNumber numberWithInt:10]
                    placeHolderImage:nil
                    delegate:self];

 imageBrower.indicatorClassName = @"ETActivityIndicatorView";
 imageBrower.progressViewName = @"DACircularProgressView";
 
 [imageBrower updateFirstURLArray:imageURLArray1 secondImageURLArray:imageURLArray2];
 [self.view addSubview:imageBrower];
 
 
 Done!!!
 
 */



@protocol KJImageBrowerViewDelegate <NSObject>

@optional

/**
 *  单击之后的回调
 */
-(void)onTappedWithImageIndex:(NSUInteger)imageIndex;


/**
 *  滑动结束之后的回调
 */
-(void)onScrollEndWithImageIndex:(NSUInteger)imageIndex;

@end


/**
 *  Image浏览功能
 */
@interface KJImageBrowserView : UIView

/**
 *  第一次加载的图像url对象列表（为空则无法显示图片），通常用于加载小图
 */
@property (nonatomic, retain) NSArray *firstLoadImageURLArray;

/**
 *  第二次加载的图像url对象列表（可以为空），如果有图，通常用于加载大图
 */
@property (nonatomic, retain) NSArray *secondLoadImageURLArray;


#pragma  mark - readonly property
/**
 *  两张图片之间的间隙
 */
@property (nonatomic, retain, readonly) NSNumber *paddingDistance;

/**
 *  浏览图像背景颜色
 */
@property (nonatomic, retain, readonly) UIColor *backgroundColor;

/**
 *  代理
 */
@property (nonatomic, weak, readonly) id<KJImageBrowerViewDelegate> delegate;

/**
 *  默认图片（可空）
 */
@property (nonatomic, retain, readonly) UIImage *placeHolderImage;

#pragma mark - 缩放相关
/**
 *  是否支持缩放
 */
@property (nonatomic, assign, readonly, getter = isSupportZoom) BOOL beSupportZoom;

/**
 *  是否支持双击缩放
 */
@property (nonatomic, assign, readonly, getter = isSupportDoubleTouch) BOOL beSupportDoubleTouch;

#pragma mark - 等待框和进度条

/**
 *  等待提示框的类名。
 *  注意：这个类一定要有startAnimating的接口来开启动画接口，否则加载图像时不会展示出来。
 */
@property (nonatomic, copy) NSString *indicatorClassName;

/**
 *  进度条提示框类名。
 *  注意：这个类一定要有progress成员变量作为setValue:forKeyPath:的KeyPath值。否则会无法正确更新当前进度
 */
@property (nonatomic, copy) NSString *progressViewName;

#pragma mark - 接口

/**
 *  更新URL数据，重新展示数据
 *
 *  @param firstLoadImageURLArray  第一个加载的数组
 *  @param secondLoadImageURLArray 第二个加载的数组
 */
-(void)updateFirstURLArray:(NSArray *)firstLoadImageURLArray
       secondImageURLArray:(NSArray *)secondLoadImageURLArray;

/**
 *  初始化KJImageBrowserView接口
 *
 *  @param frame                位置及大小          (不可空)
 *  @param paddingDistance      图片之间的间隙       (可空，默认无边距)
 *  @param placeHolderImage     placeholderImage   (可空)
 *  @param delegate             代理               (Tapped点击回调，可空)
 *
 *  @return KJImageBrowser实例
 */
-(instancetype)initWithFrame:(CGRect)frame
                     padding:(NSNumber *)paddingDistance
            placeHolderImage:(UIImage *)placeHolderImage
                    delegate:(id<KJImageBrowerViewDelegate>)delegate;

@end
